#!/bin/bash

python3 /etc/influxdbexporter/exporter/main.py /etc/influxdbexporter/config.yaml
